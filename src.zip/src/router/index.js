import Vue from 'vue'
import Router from 'vue-router'
import Game from "../views/Game"

Vue.use(Router);

let routes = [{
  path: '/',
  component: Game,
  name: 'Game',
}];

const router = new Router({
  routes
});

export default router;
