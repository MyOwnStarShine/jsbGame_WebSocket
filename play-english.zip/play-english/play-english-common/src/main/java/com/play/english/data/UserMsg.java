package com.play.english.data;

/**
 * @author chaiqx on 2019/6/10
 */
public class UserMsg {

    public static final int PRE_START = 2;//准备

    public static final int START = 3;//开始出招

    public static final int RIVAL_LEAVE = 4;//有对手离开

    public static final int RIVAL_RUN = 5;//对手非正常逃跑
}
