package com.play.english;

/**
 * @author chaiqx
 */
public class MyPartingDataEvent {

    private String carId;

    public String getCarId() {
        return carId;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }
}
